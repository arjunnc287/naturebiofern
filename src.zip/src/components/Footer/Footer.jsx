import React from "react";
import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 Botanic Healthcare | Hyderabad, India</p>
      <p>Where Science Meets Nature</p>
    </footer>
  );
}
