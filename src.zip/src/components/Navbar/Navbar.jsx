import { useState } from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <nav className="navbar">
      <div className="nav-container">
        <div className="logo">Botanic Healthcare</div>

        {/* Hamburger icon */}
        <div
          className={`menu-toggle ${menuOpen ? "active" : ""}`}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span></span>
          <span></span>
          <span></span>
        </div>

        <ul className={`nav-links ${menuOpen ? "open" : ""}`}>
          <li>
            <Link to="/" onClick={closeMenu}>
              Home
            </Link>
          </li>

          {/* About Us */}
          <li className="dropdown">
            <span>About Us ▾</span>
            <ul className="dropdown-menu">
              <li>
                <Link to="/about-us#who-we-are" onClick={closeMenu}>
                  Who We Are
                </Link>
              </li>
              <li>
                <Link to="/about-us#vision-mission" onClick={closeMenu}>
                  Vision & Mission
                </Link>
              </li>

              <li className="dropdown-sub">
                <span>Management ▸</span>
                <ul className="dropdown-submenu">
                  <li>
                    <Link to="/about-us#key-management" onClick={closeMenu}>
                      Key Management
                    </Link>
                  </li>
                  <li>
                    <Link to="/about-us#management-team" onClick={closeMenu}>
                      Management Team
                    </Link>
                  </li>
                </ul>
              </li>

              <li>
                <Link to="/about-us#csr" onClick={closeMenu}>
                  CSR
                </Link>
              </li>

              <li className="dropdown-sub">
                <span>Sustainable Synergy ▸</span>
                <ul className="dropdown-submenu">
                  <li>
                    <Link to="/about-us#sustainability" onClick={closeMenu}>
                      Sustainability
                    </Link>
                  </li>
                  <li>
                    <Link to="/about-us#organic-process" onClick={closeMenu}>
                      Organic Process
                    </Link>
                  </li>
                </ul>
              </li>

              <li>
                <Link to="/about-us#certification" onClick={closeMenu}>
                  Certification
                </Link>
              </li>
              <li>
                <Link to="/about-us#infrastructure" onClick={closeMenu}>
                  Infrastructure
                </Link>
              </li>
            </ul>
          </li>

          {/* Products */}
          <li>
            <Link to="/products" onClick={closeMenu}>
              Products
            </Link>
          </li>

          {/* Branded Ingredients */}
          <li className="dropdown">
            <span>Branded Ingredients ▾</span>
            <ul className="dropdown-menu">
              <li className="dropdown-sub">
                <span>Clinically Proven ▸</span>
                <ul className="dropdown-submenu">
                  <li>
                    <Link
                      to="/branded-ingredients#ashwalmind"
                      onClick={closeMenu}
                    >
                      AshwalMind
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#aboscurcumin"
                      onClick={closeMenu}
                    >
                      AbosCurcumin
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#menosphora"
                      onClick={closeMenu}
                    >
                      MenoSphora
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#biopepper95"
                      onClick={closeMenu}
                    >
                      BioPepper95
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#absoperine"
                      onClick={closeMenu}
                    >
                      Absoperine
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#tinoimmune"
                      onClick={closeMenu}
                    >
                      Tinoimmune
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#lipomac" onClick={closeMenu}>
                      Lipomac
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#melostaciogold"
                      onClick={closeMenu}
                    >
                      Melostacio Gold
                    </Link>
                  </li>
                </ul>
              </li>

              <li className="dropdown-sub">
                <span>Branded Ingredients ▸</span>
                <ul className="dropdown-submenu">
                  <li>
                    <Link to="/branded-ingredients#salnic" onClick={closeMenu}>
                      Salnic
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#turmalonga"
                      onClick={closeMenu}
                    >
                      Turmalonga
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#8loss" onClick={closeMenu}>
                      8Loss
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#aquamin50"
                      onClick={closeMenu}
                    >
                      AquaMin50
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#barcpure"
                      onClick={closeMenu}
                    >
                      Barcpure
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#berbix" onClick={closeMenu}>
                      Berbix
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#lutenic" onClick={closeMenu}>
                      Lutenic
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#betavive"
                      onClick={closeMenu}
                    >
                      BetaVive
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#biolivogen"
                      onClick={closeMenu}
                    >
                      BioLivogen
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#coffeelean"
                      onClick={closeMenu}
                    >
                      Coffee Lean
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#coqpure" onClick={closeMenu}>
                      CoQPure
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#cornfit" onClick={closeMenu}>
                      Cornfit
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#forlite" onClick={closeMenu}>
                      Forlite
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#garcimate"
                      onClick={closeMenu}
                    >
                      GarciMate
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#guarsol" onClick={closeMenu}>
                      Guarsol
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#gymsol" onClick={closeMenu}>
                      Gymsol
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#melostacio"
                      onClick={closeMenu}
                    >
                      Melostacio
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#mucojoint"
                      onClick={closeMenu}
                    >
                      Mucojoint
                    </Link>
                  </li>
                  <li>
                    <Link to="/branded-ingredients#sillbio" onClick={closeMenu}>
                      SillBio
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/branded-ingredients#lipsobio"
                      onClick={closeMenu}
                    >
                      LipsoBio
                    </Link>
                  </li>
                </ul>
              </li>
            </ul>
          </li>

          {/* Innovation */}
          <li className="dropdown">
            <span>Innovation ▾</span>
            <ul className="dropdown-menu">
              <li>
                <Link to="/innovation#rnd" onClick={closeMenu}>
                  R&D
                </Link>
              </li>
              <li>
                <Link to="/innovation#patent" onClick={closeMenu}>
                  Patent & Publication
                </Link>
              </li>
              <li>
                <Link to="/innovation#phytochemistry" onClick={closeMenu}>
                  Phytochemistry
                </Link>
              </li>
              <li>
                <Link to="/innovation#new-product" onClick={closeMenu}>
                  New Product Development
                </Link>
              </li>
              <li>
                <Link to="/innovation#clinical-research" onClick={closeMenu}>
                  Clinical Research
                </Link>
              </li>
              <li>
                <Link to="/innovation#quality-control" onClick={closeMenu}>
                  Quality Control
                </Link>
              </li>
            </ul>
          </li>

          {/* Resources */}
          <li className="dropdown">
            <span>Resources ▾</span>
            <ul className="dropdown-menu">
              <li>
                <Link to="/resources#news-blogs" onClick={closeMenu}>
                  News & Blogs
                </Link>
              </li>
              <li>
                <Link to="/resources#webinar" onClick={closeMenu}>
                  Webinar
                </Link>
              </li>
              <li>
                <Link to="/resources#events" onClick={closeMenu}>
                  Events
                </Link>
              </li>
              <li>
                <Link to="/resources#career" onClick={closeMenu}>
                  Career
                </Link>
              </li>

              <li className="dropdown-sub left">
                <span>Brochure</span>
                <ul className="dropdown-submenu">
                  <li>
                    <Link
                      to="/resources#lipso-bio-brochure"
                      onClick={closeMenu}
                    >
                      Lipso Bio Brochure
                    </Link>
                  </li>
                </ul>
              </li>
            </ul>
          </li>

          <li>
            <Link to="/contact" onClick={closeMenu}>
              Contact Us
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
}
