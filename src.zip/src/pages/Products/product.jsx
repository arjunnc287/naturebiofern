import "./product.css";

const products = [
  {
    name: "Ashwagandha Extract",
    img: "https://images.unsplash.com/photo-1615486364547-14d07a9a9f3b?auto=format&fit=crop&w=800&q=80",
  },
  {
    name: "Curcumin (Turmeric)",
    img: "https://images.unsplash.com/photo-1604908177441-c74f641bc7f2?auto=format&fit=crop&w=800&q=80",
  },
  {
    name: "Green Coffee Bean",
    img: "https://images.unsplash.com/photo-1590080875837-6b2c4c3b91e7?auto=format&fit=crop&w=800&q=80",
  },
  {
    name: "Boswellia Serrata",
    img: "https://images.unsplash.com/photo-1590080818119-cd3a0a3c2345?auto=format&fit=crop&w=800&q=80",
  },
];

export default function Products() {
  return (
    <div className="products">
      <header className="products-hero">
        <h1>Our Botanical Portfolio</h1>
      </header>

      <section className="product-grid">
        {products.map((p, i) => (
          <div className="product-card" key={i}>
            <img src={p.img} alt={p.name} />
            <h3>{p.name}</h3>
          </div>
        ))}
      </section>
    </div>
  );
}
