import "./Contact.css";

export default function Contact() {
  return (
    <div className="contact">
      <header className="contact-hero">
        <h1>Contact Us</h1>
      </header>

      <section className="contact-form">
        <h2>We’d Love to Hear From You</h2>
        <form>
          <input type="text" placeholder="Your Name" required />
          <input type="email" placeholder="Your Email" required />
          <textarea placeholder="Your Message" rows="5"></textarea>
          <button type="submit">Send Message</button>
        </form>
      </section>
    </div>
  );
}
