import "./AboutUs.css";

export default function AboutUs() {
  return (
    <div className="about-us-page">
      <header className="about-hero">
        <h1>About Us</h1>
        <p className="breadcrumb">Home &gt; About Us</p>
      </header>

      {/* Who We Are */}
      <section id="who-we-are" className="about-section">
        <h2>Who We Are</h2>
        <p>
          Botanic Healthcare is a world leader in developing and manufacturing
          botanical and nutraceutical ingredients for global wellness.
        </p>
      </section>

      {/* Vision & Mission */}
      <section id="vision-mission" className="about-section">
        <h2>Vision & Mission</h2>
        <p>
          <strong>Vision:</strong> To be a globally trusted botanical solutions
          provider.
        </p>
        <p>
          <strong>Mission:</strong> To merge nature with science, delivering
          sustainable wellness.
        </p>
      </section>

      {/* Management */}
      <section id="key-management" className="about-section">
        <h2>Key Management</h2>
        <p>
          Our key management team provides strategic leadership and drives the
          vision for sustainable global growth.
        </p>
      </section>

      <section id="management-team" className="about-section">
        <h2>Management Team</h2>
        <p>
          A team of experts in botany, science, and business, ensuring
          operational excellence and innovative product development.
        </p>
      </section>

      {/* CSR */}
      <section id="csr" className="about-section">
        <h2>Corporate Social Responsibility (CSR)</h2>
        <p>
          We empower communities through education, healthcare, and eco-friendly
          initiatives that enrich lives and preserve nature.
        </p>
      </section>

      {/* Sustainable Synergy */}
      <section id="sustainability" className="about-section">
        <h2>Sustainability</h2>
        <p>
          We integrate sustainable practices at every level of production to
          minimize environmental impact and conserve biodiversity.
        </p>
      </section>

      <section id="organic-process" className="about-section">
        <h2>Organic Process</h2>
        <p>
          Our ingredients are processed using eco-friendly, organic-certified
          methods that ensure purity and safety.
        </p>
      </section>

      {/* Certification */}
      <section id="certification" className="about-section">
        <h2>Certification</h2>
        <p>
          Certified by global standards like ISO, GMP, and Organic
          accreditations.
        </p>
      </section>

      {/* Infrastructure */}
      <section id="infrastructure" className="about-section">
        <h2>Infrastructure</h2>
        <p>
          World-class R&D centers and advanced extraction units supporting
          research, development, and sustainable manufacturing.
        </p>
      </section>
    </div>
  );
}
