import "./Home.css";

export default function Home() {
  return (
    <div className="home">
      <header className="hero">
        <h1>Pure Nature. Proven Science.</h1>
      </header>

      <section className="intro">
        <h2>Welcome to Botanic Healthcare</h2>
        <p>
          We’re dedicated to creating a healthier world through scientifically
          validated botanical extracts and natural ingredients. Our team
          combines innovation and tradition to deliver sustainable, high-quality
          nutraceutical solutions.
        </p>
      </section>
    </div>
  );
}
